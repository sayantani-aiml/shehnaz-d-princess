# Shahnaz D Princess Website

Portfolio frontend project.

## Structure

- index.html
- assets/css/style.css
- assets/js/script.js
- assets/images/

Open index.html in a browser or deploy using GitHub Pages.
